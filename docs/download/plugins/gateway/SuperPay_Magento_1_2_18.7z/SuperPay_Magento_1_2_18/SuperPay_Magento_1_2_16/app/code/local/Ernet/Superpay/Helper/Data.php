<?php

class Ernet_Superpay_Helper_Data extends Mage_Core_Helper_Abstract
{

}