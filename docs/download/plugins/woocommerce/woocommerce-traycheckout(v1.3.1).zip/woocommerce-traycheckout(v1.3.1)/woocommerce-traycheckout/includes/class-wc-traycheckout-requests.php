<?php

if ( ! class_exists( 'WC_Traycheckout_Requests' ) ) :

/**
 * WooCommerce TrayCheckout main class.
 */

class WC_Traycheckout_Requests{
    
    public function getRequests() {
        global $wpdb;
        
        $requests = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}woocommerce_traycheckout_request ORDER BY control_id DESC");
        
        return $requests;
        
    }
    
    public function convertRequestParams($oldParams) {
        $newParams = "";
        
        foreach ($oldParams as $key => $value) {
            $newParams .= $key."=".$value."\n";
        }
        return $newParams;
    }
    public function addRequest($param, $environment = "no") {
        global $wpdb;
        
        $param["request_params"] = $this->convertRequestParams($param["request_params"]);
        
        if($environment == "yes"){
            $retorno = $wpdb->insert($wpdb->prefix."woocommerce_traycheckout_request",$param,array("%s","%s"));
        }
        
    }
}
endif;