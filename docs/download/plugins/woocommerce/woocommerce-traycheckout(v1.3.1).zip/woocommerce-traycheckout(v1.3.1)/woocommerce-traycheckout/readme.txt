=== WooCommerce TrayCheckout ===
Contributors: Integração TrayCheckout
Tags: woocommerce, traycheckout, payment
Requires at least: 4.0
Tested up to: 4.2
Stable tag: 1.0.0
License: GPLv2 or later.
License URI: http://www.gnu.org/licenses/gpl-2.0.html

  _______                 _____ _               _               _
 |__   __|               / ____| |             | |             | |
    | |_ __ __ _ _   _  | |    | |__   ___  ___| | _____  _   _| |_
    | | '__/ _` | | | | | |    | '_ \ / _ \/ __| |/ / _ \| | | | __|
    | | | | (_| | |_| | | |____| | | |  __/ (__|   < (_) | |_| | |_
    |_|_|  \__,_|\__, |  \_____|_| |_|\___|\___|_|\_\___/ \__,_|\__|
                  __/ |                           do grupo "Locaweb"
                 |___/

Plugin de Integração TrayCheckout - WooCommerce

== Description ==

### Plugin de Integração TrayCheckout - WooCommerce ###

TrayCheckout is a payment facilitator that offers benefits to merchants and buyers. Focused on practicality and conversion, enables virtual stores offer many payments possibilites, no need contracts with financial operators. 
 
This module is able to do the integration with the Payment API of the TrayCheckout. In this case, the consumer isn't redirect to TrayCheckout environment. Every steps of the payment are made in the Magento Checkout. 

### Descrição em Português: ###
 
O TrayCheckout é um facilitador de pagamento que oferece benefícios aos lojistas e aos compradores. Focado em praticidade e conversão, possibilita que as lojas virtuais ofereçam diversas formas de pagamento, sem burocracia ou necessidade de contrato com operadoras financeiras. 
 
Este módulo é capaz de fazer a integração com a API do pagamento do TrayCheckout. Neste caso, o consumidor não é redirecionar para ambiente TrayCheckout. Todos os passos de o pagamento são feito no Checkout Magento.

= Dependência =

Este plugin depende dos campos do plugin [WooCommerce Extra Checkout Fields for Brazil](http://wordpress.org/plugins/woocommerce-extra-checkout-fields-for-brazil/), desta forma é possível enviar os campos de "CPF", "número do endereço" e "bairro" (para o Checkout Transparente é obrigatório o uso deste plugin).

= Instalação =

Para mais informações sobre a instalação e configuração do módulo acesse [Instalação Módulo WooCommerce]().

= 1.0.0 =

* Versão incial do plugin.

= 1.3.1 =

Correção de bug campo de parcelamento. Implementado consulta no js caso campo numero do cartão esteja preenchido.